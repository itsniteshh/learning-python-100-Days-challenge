def is_leap(year):
  if year % 4 == 0:
    if year % 100 == 0:
      if year % 400 == 0:
        return True
      else:
        return False
    else:
      return True
  else:
    return False

def days_in_month(yr, mnt):
  month_days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]  
  if mnt == 1:
    return month_days[0]
  elif mnt == 2:
    if is_leap(yr) == False:
      return month_days[1]
    else:
      return 29
  elif mnt == 3:
    return month_days[2]
  elif mnt == 4:
    return month_days[3]
  elif mnt == 5:
    return month_days[4]
  elif mnt == 6:
    return month_days[5]
  elif mnt == 7:
    return month_days[6]
  elif mnt == 8:
    return month_days[7]
  elif mnt == 9:
    return month_days[8]
  elif mnt == 10:
    return month_days[9]
  elif mnt == 11:
    return month_days[10]
  elif mnt == 12:
    return month_days[11]
  else:
    return "Invalid input"
  
  
#🚨 Do NOT change any of the code below 
year = int(input("Enter a year: "))
month = int(input("Enter a month num: "))
days = days_in_month(year, month)
print(days)












