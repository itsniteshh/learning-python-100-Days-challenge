# 🚨 Don't change the code below 👇
two_digit_number = input("Type a two digit number: ")
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇


first = two_digit_number[0]
second = two_digit_number[1]

sum = int(first)  + int(second)
print(sum)