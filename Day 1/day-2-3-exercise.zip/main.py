# 🚨 Don't change the code below 👇
age = int(input("What is your current age? "))
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
#remaining age 
remaining_age = 90 - age

#age in days
age_in_days = remaining_age * 365

#age in weeks
age_in_weeks = remaining_age * 52

#age in months
age_in_months = remaining_age * 12

print(f"You have {age_in_days} days, {age_in_weeks} weeks, and {age_in_months} months remaining to live on an average.")






