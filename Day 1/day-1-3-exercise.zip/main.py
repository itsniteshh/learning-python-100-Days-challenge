#Write your code below this line 👇


name = input("Enter ur name: ")
print(len(name))





