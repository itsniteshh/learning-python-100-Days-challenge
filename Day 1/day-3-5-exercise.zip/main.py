# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("\nWhat is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

names = name1 + name2

t = names.count("t")
r = names.count("r")
u = names.count("u")
e = names.count("e")
compatibility1 = t+r+u+e

l = names.count("l")
o = names.count("o")
v = names.count("v")
e = names.count("e")
compatibility2 = l+o+v+e

score = (str(compatibility1) + str(compatibility2))

if score < '10' or score > '90':
  print('you both are gem together')
elif score > '40' or score < '50':
  print('you both are alright together')
else:
  print('you both need to find a new partner')

 