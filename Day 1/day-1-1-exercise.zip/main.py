#Write your code below this line 👇

print("""Day-1 Python Print Function
The function is declared like this:
print("What to print")"""
)







