#1. Create a greeting for your program.
print("hey friend!")

#2. Ask the user for the city that they grew up in.
city = input("Enter the city where you grew: \n")
#3. Ask the user for the name of a pet.
pet = input("Enter your pet name: \n")
#4. Combine the name of their city and pet and show them their band name.
band_name = city.title() + pet.title()
print(band_name)
#5. Make sure the input cursor shows on a new line, see the example at:
#   https://band-name-generator-end.appbrewery.repl.run/