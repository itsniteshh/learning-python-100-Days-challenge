## Debug Leap Year

# Instructions

- Read this the code in main.py
- Spot the problems 🐞. 
- Modify the code to fix the program. 
- No shortcuts - don't copy-paste to replace the code entirely with a working solution. 

Fix the code so that it works and when you hit submit it should pass all the tests.

# Solution

[https://repl.it/@appbrewery/day-13-2-solution](https://repl.it/@appbrewery/day-13-2-solution)