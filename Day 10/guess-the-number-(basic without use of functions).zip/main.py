#Number Guessing Game Objectives:
import random
from art import logo
# Include an ASCII art logo.
# Allow the player to submit a guess for a number between 1 and 100.
# Check user's guess against actual answer. Print "Too high." or "Too low." depending on the user's answer.
  
print(logo)
# If they run out of turns, provide feedback to the player. 
# Include two different difficulty levels (e.g., 10 guesses in easy mode, only 5 guesses in hard mode).
number = random.randint(1, 100+1)
print("Welcome to the Number Guessing Game")
print("I'm thinking of a number between 1 to 100")
difficulty = input(f"Choose a difficulty. Type 'easy' or 'hard':\n")
print("The answer is ", number)

easy_attempts = 5
hard_attempts = 3
end_of_guess = True

while end_of_guess:
  if difficulty == "easy":
    print(f"You have {easy_attempts} attempts remaining")
    user_guess = int(input("Make your guess: "))
    if user_guess == number:
      print(f"You've guessed the number {number} correctly")
      break
    elif user_guess < number:
      print("Too low")
      easy_attempts = easy_attempts - 1
      if easy_attempts == 0:
        end_of_guess = False
    else:
      print("Too High")
      easy_attempts = easy_attempts - 1
      if easy_attempts == 0:
        end_of_guess = False

  else:
    print(f"You have {hard_attempts} attempts remaining")
    user_guess = int(input("Make your guess: "))
    
    if user_guess == number:
      print(f"You've guessed the number {number} correctly")
      break
      
    elif user_guess < number:
      print("Too low")
      hard_attempts = hard_attempts - 1
      if hard_attempts == 0:
        end_of_guess = False

    else:
      print("Too High")
      hard_attempts = hard_attempts - 1
      if hard_attempts == 0:
        end_of_guess = False

if user_guess != number:
  print("Out of guesses! You lose")