#Write your code below this row 👇
total = 0

for numbers in range(0, 100+1):
  if numbers % 2 == 0:
    total += numbers
  
print(total)
