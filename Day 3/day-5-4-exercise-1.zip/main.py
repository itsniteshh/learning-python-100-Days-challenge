#Write your code below this row 👇

for number in range(1, 100+1):
  if number % 15 == 0:
    print("Fizzbuzz")
  elif number % 3 == 0:
    print("Fizz")
  elif number % 5 == 0:
    print("Buzz")
  else:
    print(number)