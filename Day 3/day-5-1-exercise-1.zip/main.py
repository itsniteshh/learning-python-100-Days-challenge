# 🚨 Don't change the code below 👇
student_heights = input("Input a list of student heights ").split()
for n in range(0, len(student_heights)):
  student_heights[n] = int(student_heights[n])
# 🚨 Don't change the code above 👆

count = 0
total_height = 0
#Write your code below this row 👇

for height in student_heights:
  total_height += height
  count += 1


print(f"Total height of all the students is {total_height}")
avg_height = total_height / count
print(f"Average height  of all {count} students is {avg_height}")


