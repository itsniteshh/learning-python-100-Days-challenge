import random

rock = '''
Rock
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
Paper
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
Scissors
    ____
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

choice = int(input("""
Press 0 for paper, 1 for rock and 2 for scissors
\nEnter your choice: """))

if choice == 0:
  print("You chose: ")
  print(paper)

elif choice == 1:
  print("You chose: ")
  print(rock)

elif choice == 2:
  print("You chose: ")
  print(scissors)

#com input
com = random.randint(0, 2)
if com == 0:
  print("Com chose: ")
  print(paper)

elif com == 1:
  print("Com chose: ")
  print(rock)

elif com == 2:
  print("Com chose: ")
  print(scissors)


#Rock wins against scissors.
#Scissors win against paper.
#Paper wins against rock.

if choice == 0 and com == 1:
  print("You win")
elif choice == 1 and com == 2:
  print("You win")
elif choice == 2 and com == 0:
  print("You win")
elif choice == com:
  print("Match drawn")
else:
  print("You lose")