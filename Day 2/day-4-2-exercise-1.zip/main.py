# Split string method
import random

names_string = input("Give me everybody's names, separated by a comma. ").upper()
names = names_string.split(",")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
bill = random.choice(names)
#print(type(names))
print(f"{bill} has to pay today's bill")


