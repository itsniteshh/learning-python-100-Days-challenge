#Write your code below this line 👇
#Hint: Remember to import the random module first. 🎲
import random

words = ("Heads", "Tails")
guess = random.choice(words)
print(guess)










