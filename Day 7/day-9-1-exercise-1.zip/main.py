student_scores = {
  "Harry": 81,
  "Ron": 78,
  "Hermione": 99, 
  "Draco": 74,
  "Neville": 62,
}
# 🚨 Don't change the code above 👆

#TODO-1: Create an empty dictionary called student_grades.

student_grades = {}
#TODO-2: Write your code below to add the grades to student_grades.👇
for k, v in student_scores.items():
  if student_scores[k] >= 91:
    student_scores[k] = "Outstanding"
  elif student_scores[k] >= 81:
    student_scores[k] = "Exceeds Ecpectations"
  elif student_scores[k] >= 71:
    student_scores[k] = "Acceptable"
  else:
    student_scores[k] = "Fail"
    
student_grades = student_scores
# 🚨 Don't change the code below 👇
print(student_grades)





