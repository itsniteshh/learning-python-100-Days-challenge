from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo

bids = {}

def highest_bidder(bid_record):
  winner = ""
  highest_bid = 0
  for bidder in bid_record:
    bid_amount = bid_record[bidder]
    if bid_amount > highest_bid:
      highest_bid = bid_amount
      winner = bidder
  print(f"The highest bidder is {winner} with {highest_bid} bid")

end_of_game = True
while end_of_game:
  clear()
  print(logo)
  name = input("Enter your name: \n")
  value = int(input("Enter bid: \n"))
  bids[name] = value
  poll = input("Press 'yes' if you want to bid again else 'no': \n")
  if poll == "no":
    end_of_game = False
    highest_bidder(bids)
  else:
    clear()


print(bids)